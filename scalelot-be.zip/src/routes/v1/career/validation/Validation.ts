export default class Validation{

}